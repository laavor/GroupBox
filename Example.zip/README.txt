UI Java Script to give productivity to your code.

www.laavor.com

Help maintain Laavor
https://www.paypal.com/donate/?hosted_button_id=EZRQ36MSXT8F8&source=url

Fernando Candido
Contact: support@laavor.com

OBS: It is not necessary to use JQuery.